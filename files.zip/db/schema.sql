-- Users: last_xp_ts epoch seconds for cooldown / daily resets
CREATE TABLE IF NOT EXISTS users (
  user_id INTEGER PRIMARY KEY,
  xp INTEGER NOT NULL DEFAULT 0,
  clearance_level INTEGER NOT NULL DEFAULT 0,
  last_xp_ts INTEGER DEFAULT 0,
  daily_xp INTEGER DEFAULT 0,
  last_daily_reset INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS state (
  key TEXT PRIMARY KEY,
  value TEXT
);

-- Track promotions (including manual)
CREATE TABLE IF NOT EXISTS promotions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  old_level INTEGER NOT NULL,
  new_level INTEGER NOT NULL,
  reason TEXT,
  actor_id INTEGER,
  ts INTEGER NOT NULL
);

-- Placeholder for automod rule mappings
CREATE TABLE IF NOT EXISTS automod_rules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id INTEGER NOT NULL,
  rule_id INTEGER NOT NULL,
  profile_tag TEXT,
  ts_created INTEGER
);