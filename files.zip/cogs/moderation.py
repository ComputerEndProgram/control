# Placeholder moderation cog: future implementation
import discord
from discord.ext import commands
from discord import app_commands

class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="pingmod", description="Test moderation cog is loaded (will be removed later).")
    async def pingmod(self, interaction: discord.Interaction):
        await interaction.response.send_message("Moderation systems online (placeholder).", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Moderation(bot))