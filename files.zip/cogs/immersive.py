import discord
from discord.ext import commands
from discord import app_commands
import random

MISSION_TYPES = ["Recon", "Intercept", "Extraction", "Counterintelligence", "Surveillance"]
MISSION_OBJECTIVES = ["Secure data fragment", "Plant signal beacon", "Identify rogue asset", "Trace encrypted relay", "Deploy sensor mesh"]

class Immersive(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="mission", description="Generate a random mission objective.")
    async def mission(self, interaction: discord.Interaction):
        if not self.bot.config.enable_immersive:
            await interaction.response.send_message("Immersive features disabled.", ephemeral=True)
            return
        mtype = random.choice(MISSION_TYPES)
        objective = random.choice(MISSION_OBJECTIVES)
        difficulty = random.randint(1,5)
        await interaction.response.send_message(
            f"[CLASSIFIED] Mission Profile\nType: {mtype}\nObjective: {objective}\nDifficulty: {difficulty}/5",
            ephemeral=True
        )

    @app_commands.command(name="encrypt", description="Encrypt text with a simple themed cipher (placeholder).")
    @app_commands.describe(text="Text to encrypt")
    async def encrypt(self, interaction: discord.Interaction, text: str):
        # Very trivial cipher placeholder (rotate by 3)
        out = []
        for c in text:
            if c.isalpha():
                base = 'A' if c.isupper() else 'a'
                out.append(chr((ord(c) - ord(base) + 3) % 26 + ord(base)))
            else:
                out.append(c)
        await interaction.response.send_message(f"Encrypted (rot3): {''.join(out)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Immersive(bot))