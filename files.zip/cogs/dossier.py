import discord
from discord.ext import commands
from discord import app_commands
from constants import CLEARANCE_ROLES, XP_THRESHOLDS
from utils.formatting import progress_bar

class Dossier(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="dossier", description="Display a user's dossier (XP, clearance, progress).")
    @app_commands.describe(user="User to inspect (defaults to yourself)")
    async def dossier(self, interaction: discord.Interaction, user: discord.Member | None = None):
        if user is None:
            user = interaction.user  # type: ignore

        xp, level, *_ = await self.bot.db.get_user(user.id)
        role_name = CLEARANCE_ROLES.get(level, "Unknown")
        # Compute next threshold
        next_level = level + 1
        if next_level in XP_THRESHOLDS:
            target = XP_THRESHOLDS[next_level]
            bar = progress_bar(xp, target)
            progress_text = f"{xp}/{target} XP\n{bar}"
        else:
            progress_text = f"{xp} XP (MAX or manual tiers ahead)"

        embed = discord.Embed(
            title=f"Dossier: {user.display_name}",
            color=discord.Color.dark_blue()
        )
        embed.add_field(name="Clearance Level", value=f"CL-{level}", inline=True)
        embed.add_field(name="Rank", value=role_name, inline=True)
        embed.add_field(name="Progress", value=progress_text, inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=True)

async def setup(bot):
    await bot.add_cog(Dossier(bot))