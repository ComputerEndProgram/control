import time
import discord
from discord.ext import commands
from constants import XP_THRESHOLDS, CLEARANCE_ROLES
from utils.formatting import progress_bar

class Leveling(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def maybe_award_xp(self, message: discord.Message):
        cfg = self.bot.config
        if message.author.bot or not message.guild:
            return
        content = message.content.strip()
        if len(content) < cfg.xp_min_length:
            return
        now = int(time.time())
        user_id = message.author.id
        xp, level, last_xp_ts, daily_xp, last_daily_reset = await self.bot.db.get_user(user_id)

        # Daily reset check (UTC day boundary)
        from datetime import datetime, timezone
        today = datetime.now(timezone.utc).date()
        last_reset_date = datetime.fromtimestamp(last_daily_reset, tz=timezone.utc).date() if last_daily_reset else None
        if last_reset_date != today:
            daily_xp = 0
            last_daily_reset = now

        # Cooldown
        if now - last_xp_ts < cfg.xp_cooldown:
            return
        if cfg.xp_daily_cap and daily_xp >= cfg.xp_daily_cap:
            return

        xp += cfg.xp_per_message
        daily_xp += cfg.xp_per_message
        await self.bot.db.update_user(
            user_id,
            xp,
            level,
            last_xp_ts=now,
            daily_xp=daily_xp,
            last_daily_reset=last_daily_reset
        )

        # Check promotion (auto only up to max)
        if level < cfg.auto_promotion_max:
            next_level = level + 1
            threshold = XP_THRESHOLDS.get(next_level)
            if threshold and xp >= threshold:
                old = level
                new = next_level
                await self.bot.db.update_user(user_id, xp, new)
                await self.bot.db.record_promotion(user_id, old, new, "XP Threshold", None)
                # Add new role (stacking)
                role_name = CLEARANCE_ROLES.get(new)
                if role_name:
                    role = discord.utils.get(message.guild.roles, name=role_name)
                    if role and role not in message.author.roles:
                        try:
                            await message.author.add_roles(role, reason="Auto promotion")
                        except discord.Forbidden:
                            pass
                # Announce
                if self.bot.config.promotion_announcements != "none":
                    chan = discord.utils.get(message.guild.text_channels, name=self.bot.config.announcements_channel)
                    if chan and self.bot.config.promotion_announcements in ("channel","both"):
                        await chan.send(f"Promotion: {message.author.mention} → {role_name}")
                    if self.bot.config.promotion_announcements in ("dm","both"):
                        try:
                            await message.author.send(f"You have advanced to {role_name}.")
                        except discord.Forbidden:
                            pass

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        # Process XP before commands
        await self.maybe_award_xp(message)
        # Let other cogs handle their logic
        await self.bot.process_commands(message)

async def setup(bot):
    await bot.add_cog(Leveling(bot))