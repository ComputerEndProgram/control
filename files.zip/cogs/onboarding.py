import discord
from discord.ext import commands
from constants import CLEARANCE_ROLES

VERIFY_MESSAGE_KEY = "verification_message_id"

class Onboarding(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def ensure_verification_message(self, guild: discord.Guild):
        cfg = self.bot.config
        if not cfg.enable_verification:
            return
        channel = discord.utils.get(guild.text_channels, name=cfg.verification_channel)
        if not channel:
            return
        db = self.bot.db
        existing_id = await db.get_state(VERIFY_MESSAGE_KEY)
        if existing_id:
            # Try to fetch; if deleted, recreate
            try:
                msg = await channel.fetch_message(int(existing_id))
                return msg
            except Exception:
                pass
        msg = await channel.send("React with ✅ to confirm Directive 01 processing and obtain Initiate clearance (CL-1).")
        await msg.add_reaction("✅")
        await db.set_state(VERIFY_MESSAGE_KEY, str(msg.id))
        return msg

    @commands.Cog.listener()
    async def on_ready(self):
        # Ensure verification message for all guilds
        for guild in self.bot.guilds:
            await self.ensure_verification_message(guild)

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        # Assign CL-0 if present
        base_role = discord.utils.get(member.guild.roles, name=CLEARANCE_ROLES[0])
        if base_role and base_role not in member.roles:
            try:
                await member.add_roles(base_role, reason="Initial onboarding")
            except discord.Forbidden:
                pass
        # DB ensure user row
        await self.bot.db.get_user(member.id)
        # DM welcome
        try:
            await member.send((
                "Welcome to Project: **SOLARIS**.\n"
                "Directive 01: Proceed to #verification and react with ✅ to advance to CL-1.\n"
                "Maintain discretion. Observation begins now."
            ))
        except discord.Forbidden:
            pass

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload: discord.RawReactionActionEvent):
        db = self.bot.db
        verify_id = await db.get_state(VERIFY_MESSAGE_KEY)
        if not verify_id or str(payload.message_id) != verify_id:
            return
        if str(payload.emoji) != "✅":
            return
        guild = self.bot.get_guild(payload.guild_id)
        if not guild:
            return
        member = guild.get_member(payload.user_id)
        if not member or member.bot:
            return
        xp, level, *_ = await db.get_user(member.id)
        if level >= 1:
            return  # already higher
        # Promote to CL-1 (stack; don't remove prior)
        old_level = level
        new_level = 1
        await db.update_user(member.id, xp, new_level)
        role = discord.utils.get(guild.roles, name=CLEARANCE_ROLES[new_level])
        if role and role not in member.roles:
            try:
                await member.add_roles(role, reason="Verification -> CL-1")
            except discord.Forbidden:
                pass
        await db.record_promotion(member.id, old_level, new_level, "Verification", None)
        # Optional announce
        chan = discord.utils.get(guild.text_channels, name=self.bot.config.announcements_channel)
        if chan:
            await chan.send(f"Access granted: {member.mention} elevated to {CLEARANCE_ROLES[new_level]}.")

async def setup(bot):
    await bot.add_cog(Onboarding(bot))