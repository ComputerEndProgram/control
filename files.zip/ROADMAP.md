# Roadmap (Condensed for Starter Template)

This file complements the more detailed plan you outlined. It focuses on immediate next steps after bootstrapping.

## Implemented in Starter
- Config loader / env
- aiosqlite async DB
- Onboarding + verification (CL-0 → CL-1)
- XP system with cooldown, min length, stacking roles
- Auto promotions up to CL-8 only
- Slash-only `/dossier`
- Role stacking (no removals)
- Placeholder cogs (moderation, immersive, automod)

## Next Suggested Phases
1. Moderation Commands: /warn /kick /ban /mute /promote /setclearance (with logging)
2. AutoMod Deploy: create/update/fetch rules, persist rule IDs
3. Mission System: /mission new /mission complete (DB integration)
4. Encryption Utilities: /encrypt /decrypt with tiered algorithms
5. Leaderboard: /leaderboard (XP ranking)
6. Logging & Observability: centralized structured logging, /status
7. Manual Promotion Tools: logging records in promotions table
8. Intelli-Drops: background tasks posting flavor text
9. CI & Linting: Ruff/Black workflows
10. Sharding / Scaling: AutoShardedBot if needed

## Data Integrity TODO
- Add daily XP cap logic tracking (table or columns exist)
- Add promotions table entries for manual promotions (stub ready)

## Security / Safety
- Ensure only staff (CL-9/10 or Discord permissions) can manual-promote above CL-8
- Add duplication checks for verification message creation

## AutoMod Badge Path
- Build curated rule profiles (phishing domains, spam heuristics, profanity tiers)
- Expose /automod status + /automod deploy profile:<name>
- Track rule counts per guild in `automod_rules` table
