import os
from dataclasses import dataclass

def _bool(val: str | None, default: bool=False) -> bool:
    if val is None:
        return default
    return val.lower() in ("1","true","yes","on")

@dataclass
class Config:
    token: str
    application_id: int | None
    dev_guild_ids: list[int]
    db_path: str
    xp_cooldown: int
    xp_per_message: int
    xp_min_length: int
    xp_daily_cap: int | None
    auto_promotion_max: int
    announcements_channel: str
    verification_channel: str
    log_channel: str
    enable_verification: bool
    enable_immersive: bool
    enable_automod: bool
    allow_dm_commands: bool
    command_sync_scope: str
    emoji_style: str
    promotion_announcements: str

def load_config() -> Config:
    token = os.getenv("DISCORD_BOT_TOKEN")
    if not token:
        raise SystemExit("Missing DISCORD_BOT_TOKEN in environment")
    app_id_raw = os.getenv("APPLICATION_ID")
    dev_ids = [int(x) for x in os.getenv("DEV_GUILD_IDS","").split(",") if x.strip().isdigit()]
    xp_daily_cap_raw = os.getenv("XP_DAILY_CAP")
    return Config(
        token=token,
        application_id=int(app_id_raw) if app_id_raw and app_id_raw.isdigit() else None,
        dev_guild_ids=dev_ids,
        db_path=os.getenv("DATABASE_PATH","solaris.db"),
        xp_cooldown=int(os.getenv("XP_COOLDOWN_SECONDS","60")),
        xp_per_message=int(os.getenv("XP_PER_MESSAGE","5")),
        xp_min_length=int(os.getenv("XP_MIN_MESSAGE_LENGTH","10")),
        xp_daily_cap=int(xp_daily_cap_raw) if xp_daily_cap_raw and xp_daily_cap_raw.isdigit() else None,
        auto_promotion_max=int(os.getenv("AUTO_PROMOTION_MAX_LEVEL","8")),
        announcements_channel=os.getenv("ANNOUNCEMENTS_CHANNEL","announcements"),
        verification_channel=os.getenv("VERIFICATION_CHANNEL","verification"),
        log_channel=os.getenv("LOG_CHANNEL","ops-logs"),
        enable_verification=_bool(os.getenv("ENABLE_VERIFICATION"), True),
        enable_immersive=_bool(os.getenv("ENABLE_IMMERSIVE"), True),
        enable_automod=_bool(os.getenv("ENABLE_AUTOMOD"), True),
        allow_dm_commands=_bool(os.getenv("ALLOW_DM_COMMANDS"), True),
        command_sync_scope=os.getenv("COMMAND_SYNC_SCOPE","guild"),
        emoji_style=os.getenv("EMOJI_STYLE","minimal"),
        promotion_announcements=os.getenv("PROMOTION_ANNOUNCEMENTS","channel"),
    )