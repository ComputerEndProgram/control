# Project: SOLARIS Bot (Starter Template)

Theme: Section 31 / Star Trek Espionage

This is a modular Discord bot implementing:
- Onboarding + verification to CL-1
- XP / clearance promotions (auto CL-0 → CL-8)
- Manual high-tier promotions (CL-9 / CL-10 only by staff)
- Slash-only commands (`/dossier`)
- Role stacking (promotions retain all lower CL roles)
- DM support for select commands
- Placeholders for moderation, AutoMod integration, immersive features

## Quick Start

1. Create a virtual environment:
   ```
   python -m venv .venv
   source .venv/bin/activate  # Windows: .venv\Scripts\activate
   ```

2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Copy `.env.example` to `.env` and fill values (token, dev guild IDs).

4. Ensure roles exist (exact names) in your server:
   ```
   CL-0: Recruit
   CL-1: Initiate
   ...
   CL-8: Intelligence Officer
   CL-9: Shadow Commander
   CL-10: Control
   ```

5. Run the bot:
   ```
   python main.py
   ```

## Database
Uses SQLite via `aiosqlite`. Schema auto-applies on startup from `db/schema.sql`.

## Auto Promotion Rules
- XP thresholds defined in `constants.py`
- Auto-promotion stops at CL-8
- CL-9 and CL-10 are manual (/promote command to be added in moderation/admin cog later)

## Verification
- On join: CL-0 assigned (if present)
- A verification message (reaction ✅) can grant CL-1
- Reaction message ID stored in DB (survives restarts)

## Extension Plan
See `ROADMAP.md` for detailed multi-phase expansion (moderation commands, AutoMod ruleset deployment, mission system, encryption, etc.).

## Notes
- To allow DM slash commands, global command sync is enabled (can throttle initially; for development use guild-only sync).
- AutoMod integration placeholder requires appropriate discord.py version or HTTP requests to endpoints not yet wrapped by the library (see `cogs/automod.py`).

## License
Add one if desired.
