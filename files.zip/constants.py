# Clearance role ladder (index = level)
CLEARANCE_ROLES = {
    0: "CL-0: Recruit",
    1: "CL-1: Initiate",
    2: "CL-2: Asset",
    3: "CL-3: Agent",
    4: "CL-4: Field Agent",
    5: "CL-5: Senior Agent",
    6: "CL-6: Special Operative",
    7: "CL-7: Handler",
    8: "CL-8: Intelligence Officer",
    9: "CL-9: Shadow Commander",
    10: "CL-10: Control",
}

# XP thresholds: XP required to REACH that level (cumulative)
# Levels 9 and 10 are manual only (do not include if you want to enforce stop at 8)
XP_THRESHOLDS = {
    1: 100,
    2: 300,
    3: 600,
    4: 1000,
    5: 1500,
    6: 2100,
    7: 2800,
    8: 3600,
    # 9 / 10 manual only
}
MAX_AUTO_LEVEL = 8