from math import floor

def progress_bar(current: int, target: int, width: int = 20) -> str:
    if target <= 0:
        return "MAX"
    ratio = min(current / target, 1)
    filled = floor(ratio * width)
    return f"[{'█'*filled}{'░'*(width-filled)}] {ratio*100:.1f}%"