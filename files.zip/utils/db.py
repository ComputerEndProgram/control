import aiosqlite
import time
from typing import Optional, Tuple

class Database:
    def __init__(self, path: str):
        self.path = path
        self._conn: aiosqlite.Connection | None = None

    async def connect(self):
        self._conn = await aiosqlite.connect(self.path)
        await self._conn.execute("PRAGMA journal_mode=WAL;")
        await self._conn.execute("PRAGMA foreign_keys=ON;")
        # Apply schema
        with open("db/schema.sql","r", encoding="utf-8") as f:
            await self._conn.executescript(f.read())
        await self._conn.commit()

    async def close(self):
        if self._conn:
            await self._conn.close()

    async def get_user(self, user_id: int) -> Tuple[int,int,int,int,int]:
        """
        Returns: xp, clearance_level, last_xp_ts, daily_xp, last_daily_reset
        """
        cur = await self._conn.execute(
            "SELECT xp, clearance_level, last_xp_ts, daily_xp, last_daily_reset FROM users WHERE user_id = ?",
            (user_id,)
        )
        row = await cur.fetchone()
        await cur.close()
        if row:
            return row
        # Insert default
        await self._conn.execute(
            "INSERT OR IGNORE INTO users (user_id) VALUES (?)",
            (user_id,)
        )
        await self._conn.commit()
        return 0,0,0,0,0

    async def update_user(self, user_id: int, xp: int, level: int,
                          last_xp_ts: Optional[int]=None,
                          daily_xp: Optional[int]=None,
                          last_daily_reset: Optional[int]=None):
        fields = ["xp = ?", "clearance_level = ?"]
        values = [xp, level]
        if last_xp_ts is not None:
            fields.append("last_xp_ts = ?")
            values.append(last_xp_ts)
        if daily_xp is not None:
            fields.append("daily_xp = ?")
            values.append(daily_xp)
        if last_daily_reset is not None:
            fields.append("last_daily_reset = ?")
            values.append(last_daily_reset)
        values.append(user_id)
        await self._conn.execute(
            f"UPDATE users SET {', '.join(fields)} WHERE user_id = ?",
            tuple(values)
        )
        await self._conn.commit()

    async def record_promotion(self, user_id: int, old_level: int, new_level: int, reason: str | None, actor_id: int | None):
        await self._conn.execute(
            "INSERT INTO promotions (user_id, old_level, new_level, reason, actor_id, ts) VALUES (?, ?, ?, ?, ?, ?)",
            (user_id, old_level, new_level, reason, actor_id, int(time.time()))
        )
        await self._conn.commit()

    async def get_state(self, key: str) -> str | None:
        cur = await self._conn.execute("SELECT value FROM state WHERE key = ?", (key,))
        row = await cur.fetchone()
        await cur.close()
        return row[0] if row else None

    async def set_state(self, key: str, value: str):
        await self._conn.execute(
            "INSERT INTO state (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key,value)
        )
        await self._conn.commit()