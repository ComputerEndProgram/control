from discord import app_commands, Interaction
from constants import CLEARANCE_ROLES

# Placeholder; real check would pull from DB or a cache
def clearance_required(min_level: int):
    async def predicate(interaction: Interaction):
        # Bot stores ephemeral cache maybe; fallback to DB retrieval cog
        db = interaction.client.db  # type: ignore
        xp, level, *_rest = await db.get_user(interaction.user.id)
        if level >= min_level:
            return True
        raise app_commands.CheckFailure(f"Requires clearance level {min_level} ({CLEARANCE_ROLES.get(min_level)})")
    return app_commands.check(predicate)