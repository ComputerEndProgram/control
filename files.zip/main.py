import discord
from discord.ext import commands
import asyncio
from config import load_config
from utils.db import Database
import logging
import sys

INTENTS = discord.Intents.default()
INTENTS.members = True
INTENTS.message_content = True  # required for XP system
INTENTS.guilds = True
INTENTS.messages = True
INTENTS.reactions = True

class SolarisBot(commands.Bot):
    def __init__(self, config):
        super().__init__(
            command_prefix=None,  # Slash-only
            intents=INTENTS,
            application_id=config.application_id
        )
        self.config = config
        self.db: Database | None = None
        self.initial_extensions = [
            "cogs.onboarding",
            "cogs.leveling",
            "cogs.dossier",
            "cogs.moderation",
            "cogs.immersive",
            "cogs.automod",
        ]

    async def setup_hook(self):
        # DB
        self.db = Database(self.config.db_path)
        await self.db.connect()
        # Load cogs
        for ext in self.initial_extensions:
            try:
                await self.load_extension(ext)
            except Exception as e:
                logging.exception(f"Failed to load {ext}: {e}")

        # Command Sync
        if self.config.command_sync_scope == "guild" and self.config.dev_guild_ids:
            for gid in self.config.dev_guild_ids:
                guild_obj = discord.Object(id=gid)
                await self.tree.sync(guild=guild_obj)
            print(f"Synced {len(self.tree.get_commands())} commands to dev guilds.")
        else:
            await self.tree.sync()
            print(f"Globally synced {len(self.tree.get_commands())} commands.")

    async def on_ready(self):
        print(f"Logged in as {self.user} (ID: {self.user.id})")
        activity = discord.Activity(type=discord.ActivityType.watching, name="Agent Activity")
        await self.change_presence(activity=activity)

    async def close(self):
        if self.db:
            await self.db.close()
        await super().close()

def configure_logging():
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        handlers=[logging.StreamHandler(sys.stdout)]
    )

def main():
    configure_logging()
    cfg = load_config()
    bot = SolarisBot(cfg)
    bot.run(cfg.token)

if __name__ == "__main__":
    main()